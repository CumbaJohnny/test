<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">

            <div class="portlet light bordered">
                <div class="portlet-body form">

                    <div class="panel-group" id="accordion3" role="tablist" aria-multiselectable="true">

                        <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="panel panel-primary">
                            <div class="panel-heading" role="tab" id="headingOne">
                                <h4 class="panel-title">
                                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#generalOne<?php echo e($f->id); ?>" aria-expanded="true" aria-controls="collapseOne<?php echo e($f->id); ?>">
                                        <?php echo e($f->title); ?>

                                    </a>
                                </h4>
                            </div>
                            <div id="generalOne<?php echo e($f->id); ?>" class="panel-collapse collapse <?php echo e($key == 0 ? 'in' : ''); ?>" role="tabpanel" aria-labelledby="headingOne<?php echo e($f->id); ?>">
                                <div class="panel-body">
                                    <?php echo $f->description; ?>

                                    <br>
                                    <br>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <a href="<?php echo e(route('faqs-edit',$f->id)); ?>" class="btn btn-primary btn-block bold uppercase"><i class="fa fa-edit"></i> Edit faqs</a>
                                        </div>
                                        <div class="col-md-6">
                                            <button type="button" class="btn btn-danger bold uppercase btn-block delete_button"
                                                    data-toggle="modal" data-target="#DelModal"
                                                    data-id="<?php echo e($f->id); ?>">
                                                <i class='fa fa-trash'></i> Delete faqs
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="text-center">
                            <?php echo $faqs->links(); ?>

                        </div>

                    </div>

                </div>
            </div>
        </div>
    </div>

    <!-- Modal for DELETE -->
    <div class="modal fade" id="DelModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title bold" id="myModalLabel"> <i class='fa fa-exclamation-triangle'></i> Confirmation !</h4>
                </div>

                <div class="modal-body">
                    <strong>Are you sure you want to Delete ?</strong>
                </div>

                <div class="modal-footer">
                    <form method="post" action="<?php echo e(route('faqs-delete')); ?>" class="form-inline">
                        <?php echo csrf_field(); ?>

                        <?php echo e(method_field('DELETE')); ?>

                        <input type="hidden" name="id" class="abir_id" value="0">
                        <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
                        <button type="submit" class="btn btn-danger"><i class="fa fa-trash"></i> DELETE</button>
                    </form>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

    <?php if(session('alert')): ?>

        <script type="text/javascript">

            $(document).ready(function(){

                swal("Sorry!", "<?php echo session('alert'); ?>", "error");

            });

        </script>

    <?php endif; ?>

    <script>
        $(document).ready(function () {

            $(document).on("click", '.delete_button', function (e) {
                var id = $(this).data('id');
                $(".abir_id").val(id);
            });
        });
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>