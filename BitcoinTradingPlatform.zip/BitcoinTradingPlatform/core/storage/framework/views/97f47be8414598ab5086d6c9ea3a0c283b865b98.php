<?php $__env->startSection('style'); ?>

    <link rel="stylesheet" href="<?php echo e(asset('assets/css/ion.rangeSlider.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/ranger-style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/ion.rangeSlider.skinFlat.css')); ?>">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section class="header-section ">
    <div class="head-slider">
        

        <?php $__currentLoopData = $slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="single-header slider header-bg" style="background-image: url('<?php echo e(asset('assets/images/slider')); ?>/<?php echo e($s->image); ?>')">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12 text-center">
                            <div class="header-slider-wrapper">
                                <h1><?php echo e($s->title); ?></h1>
                                <p><?php echo e($s->subtitle); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
</section><!--Header section end-->

<!--About community Section Start-->
<section class="section-padding about-community">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="section-title text-center">
                    <h2>about - <?php echo e($site_title); ?></h2>
                    <p><?php echo $page->about_subtitle; ?></p>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <p class="about-community-text text-right">
                    <?php echo $page->about_leftText; ?>

                </p>
            </div>
            <div class="col-md-6">
                <p class="about-community-text">
                    <?php echo $page->about_rightText; ?>

                </p>
            </div>
        </div>
    </div>
</section><!--About community Section end-->

<!--service section start-->
<section class="section-padding service-section">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="section-title text-center section-padding padding-bottom-0">
                    <h2>Services - <?php echo e($site_title); ?></h2>
                    <p><?php echo $page->service_subtitle; ?></p>
                </div>
            </div>
        </div>
        <div class="row">
            <?php $__currentLoopData = $service; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-3 col-sm-6">
                <div class="service-wrapper text-center">
                    <div class="service-icon ">
                        <?php echo $s->code; ?>

                    </div>
                    <div class="service-title">
                        <p><?php echo e($s->title); ?></p>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section><!--service section end-->


<!--Our Plan section start-->
<section class="section-padding our-plan">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="section-title text-center">
                    <h2 class="color-text">Our awesome plans</h2>
                    <p><?php echo $page->plan_subtitle; ?></p>
                </div>
            </div>
        </div>
        <div class="row">

            <?php $__currentLoopData = $plan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                <div class="col-md-3 col-sm-6">
                    <div class="price-table text-center">
                        <div class="price-table-header">
                            <h4><?php echo e($p->name); ?></h4>
                            <p><?php echo e($p->compound->name); ?> <?php echo e($p->percent); ?>% for <?php echo e($p->time); ?> times</p>
                        </div>
                        <div class="price-table-body">
                            <p> <span class="color-text"><?php echo e($p->compound->name); ?></span> Return</p>
                            <p>for <span class="color-text"><?php echo e($p->time); ?></span> times</p>
                            <p> <span class="color-text"><?php echo e($p->percent); ?>%</span> roi each time</p>
                            <div class="price-range">
                                <div class="row">
                                    <div class="col-md-6 text-left col-sm-6 col-xs-6">
                                        <div class="min-price">
                                            <h6>Minimum<span class="color-text"><?php echo e($basic->symbol); ?> <?php echo e($p->minimum); ?></span></h6>
                                        </div>
                                    </div>
                                    <div class="col-md-6 text-right col-sm-6 col-xs-6">
                                        <div class="min-price">
                                            <h6>Maximum<span class="color-text"><?php echo e($basic->symbol); ?> <?php echo e($p->maximum); ?></span></h6>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="invest-type__profit plan__value--<?php echo e($p->id); ?>">
                                <input type="text" value="<?php echo e($basic->symbol); ?> <?php echo e(($p->minimum + $p->maximum) / 2); ?>" class="custom-input invest-type__profit--val" data-slider=".slider-input--<?php echo e($p->id); ?>">
                                <input type="hidden" name="amount" value="<?php echo e(($p->minimum + $p->maximum) / 2); ?>" class=" slider-input slider-input--<?php echo e($p->id); ?>" data-perday="<?php echo e($p->percent); ?>" data-peryear="<?php echo e($p->time); ?>" data-min="<?php echo e($p->minimum); ?>" data-max="<?php echo e($p->maximum); ?>" data-dailyprofit=".daily-profit-<?php echo e($p->id); ?>" data-totalprofit=".total-profit-<?php echo e($p->id); ?> " data-valuetag=".plan__value--<?php echo e($p->id); ?> .invest-type__profit--val"/>
                            </div>
                            <input type="hidden" name="plan_id" value="<?php echo e($p->id); ?>">
                            <div class="price-range">
                                <div class="row">
                                    <div class="col-md-6 text-left col-sm-6 col-xs-6 invest-type__calc invest-type__calc--daily">
                                        <div class="min-price">
                                            <h6>per time<span class="color-text"><b class="daily-profit-<?php echo e($p->id); ?>"><?php echo e($basic->symbol); ?> <?php echo e((($p->minimum + $p->maximum) / 2 ) * $p->percent /100); ?>.0</b></span></h6>
                                        </div>
                                    </div>
                                    <div class="col-md-6 text-right col-sm-6 col-xs-6 invest-type__calc invest-type__calc--total">
                                        <div class="min-price">
                                            <h6>Total Return<span class="color-text"><b class="total-profit-<?php echo e($p->id); ?>"><?php echo e($basic->symbol); ?> <?php echo e((((($p->minimum + $p->maximum) / 2) * $p->percent) /100 ) * $p->time); ?>.0</b></span></h6>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="price-table-footer">
                            <a href="<?php echo e(route('register')); ?>" class="boxed-btn">sign up</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="row section-padding padding-bottom-0">
            <div class="col-md-6 col-sm-6">
                <div class="contact-info">
                    <div class="contact-title">
                        <h4>Have a question <span>we are here to help!</span></h4>
                    </div>
                    <div class="contact-details">
                        <p><i class="fa fa-phone"></i> <?php echo e($basic->phone); ?></p>
                        <p><i class="fa fa-envelope"></i> <?php echo e($basic->email); ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-sm-6">
                <div class="discunt-text">
                    <h3><?php echo e($basic->reference_percent); ?><i class="fa fa-percent"></i> <br /> referral <br /> commission</h3>
                </div>
            </div>
        </div>

    </div>
</section><!--Our Plan section end-->

<!--Project Done so far start-->
<section class="completed-projcets section-padding">
    <div class="container">
        <div class="row text-center">
            <div class="col-md-3 col-sm-6">
                <div class="happy-clients-box">
                    <div class="happy-clients-icon">
                        <i class="fa fa-user"></i>
                    </div>
                    <div class="happy-clients-text">
                        <h4 class="counter" data-count="<?php echo e($total_user); ?>">0 </h4>
                        <p>Total User</p>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-sm-6">
                <div class="happy-clients-box">
                    <div class="happy-clients-icon">
                        <i class="fa fa-recycle"></i>
                    </div>
                    <div class="happy-clients-text">
                        <h4 class="counter" data-count="<?php echo e($total_repeat); ?>" >0</h4>
                        <p>Total Repeat</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="happy-clients-box">
                    <div class="happy-clients-icon">
                        <i class="fa fa-cloud-download"></i>
                    </div>
                    <div class="happy-clients-text">
                        <h4 class="counter" data-count="<?php echo e($total_deposit); ?>">0 </h4>
                        <p>Total Deposit</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="happy-clients-box">
                    <div class="happy-clients-icon">
                        <i class="fa fa-cloud-upload"></i>
                    </div>
                    <div class="happy-clients-text">
                        <h4 class="counter" data-count="<?php echo e($total_withdraw); ?>" >0 </h4>
                        <p>Total Withdraw</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section><!--Project Done so far end-->

<!--Our Top Investor Section Start-->
<section class="section-padding top-investor">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="section-title text-center">
                    <h2 class="color-text">Our top Investors</h2>
                    <p><?php echo e($page->investor_subtitle); ?></p>
                </div>
            </div>
        </div>
        <div class="row text-center">
            <?php $__currentLoopData = $top_investor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $inv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-3 col-sm-6">
                <div class="single-investor-wrapper <?php if($key % 2 != 0): ?> color-onvestor <?php endif; ?> ">
                    <h4><?php echo e(\App\User::findOrFail($inv->user_id)->name); ?></h4>
                    <p><?php echo e($basic->symbol); ?> <?php echo e($inv->total_invest); ?></p>
                </div>
            </div>

            
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section><!--Our Top Investor Section Start-->

<!--testimonial section start-->
<section class="section-padding  testimonial-section">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="section-title text-center">
                    <h2 class="color-text">What People Say</h2>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6 col-md-offset-3">
                <div class="slider-activation">
                    <?php $__currentLoopData = $testimonial; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="testimonial-carousel">
                        <div class="single-testimonial-wrapper">
                            <div class="single-testimonial-top">
                                <div class="testimoanial-top-text">
                                    <div class="profile-pic">
                                        <img src="<?php echo e(asset('assets/images')); ?>/<?php echo e($tes->image); ?>" class="img-circle img-responsive" alt="Client's Profile Pic">
                                    </div>
                                    <h4><?php echo e($tes->name); ?><span><?php echo e($tes->position); ?></span></h4>
                                </div>
                                <div class="testimonial-bottom">
                                    <p><?php echo $tes->message; ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

            </div>
        </div>
    </div>
</section><!--testimonial section end-->

<!--Deopsit and Payouts section start-->
<section class="section-padding">
    <div class="container">
        <div class="row text-center">
            <div class="col-md-6">
                <div class="deposit-table">
                    <div class="deposit-title">
                        <h4>Latest Deposits</h4>
                    </div>
                    <div class="deposit-body">
                        <table class="table main-table">

                            <tbody>
                            <tr class="head">
                                <th>Name</th>
                                <th>Date</th>
                                <th>Currency</th>
                                <th>Amount</th>
                            </tr>
                            <?php $__currentLoopData = $latest_deposit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ld): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($ld->member->name); ?></td>
                                <td><?php echo e(\Carbon\Carbon::parse($ld->created_at)->format('M d,Y')); ?></td>
                                <td><strong><?php echo e($basic->currency); ?></strong></td>
                                <td><strong><?php echo e($basic->symbol); ?><?php echo e($ld->amount); ?></strong></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="deposit-table">
                    <div class="deposit-title">
                        <h4>Latest Withdraw</h4>
                    </div>
                    <div class="deposit-body">
                        <table class="table main-table">

                            <tbody>
                            <tr class="head">
                                <th>Name</th>
                                <th>Date</th>
                                <th>Currency</th>
                                <th>Amount</th>
                            </tr>
                            <?php $__currentLoopData = $latest_withdraw; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ld): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($ld->member->name); ?></td>
                                    <td><?php echo e(\Carbon\Carbon::parse($ld->created_at)->format('M d,Y')); ?></td>
                                    <td><strong><?php echo e($basic->currency); ?></strong></td>
                                    <td><strong><?php echo e($basic->symbol); ?><?php echo e($ld->amount); ?></strong></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section><!--Deopsit and Payouts Section End-->


<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script type="text/javascript" src="<?php echo e(asset('assets/js/ion.rangeSlider.js')); ?>"></script>
    <script>
        $.each($('.slider-input'), function() {
            var $t = $(this),

                    from = $t.data('from'),
                    to = $t.data('to'),

                    $dailyProfit = $($t.data('dailyprofit')),
                    $totalProfit = $($t.data('totalprofit')),

                    $val = $($t.data('valuetag')),

                    perDay = $t.data('perday'),
                    perYear = $t.data('peryear');


            $t.ionRangeSlider({
                input_values_separator: ";",
                prefix: '<?php echo e($basic->symbol); ?> ',
                hide_min_max: true,
                force_edges: true,
                onChange: function(val) {
                    $val.val( '<?php echo e($basic->symbol); ?> ' + val.from);

                    var profit = (val.from * perDay / 100).toFixed(1);
                    profit  = '<?php echo e($basic->symbol); ?> ' + profit.replace('.', '.') ;
                    $dailyProfit.text(profit) ;

                    profit = ( (val.from * perDay / 100)* perYear ).toFixed(1);
                    profit  =  '<?php echo e($basic->symbol); ?> ' + profit.replace('.', '.');
                    $totalProfit.text(profit);

                }
            });
        });
        $('.invest-type__profit--val').on('change', function(e) {

            var slider = $($(this).data('slider')).data("ionRangeSlider");

            slider.update({
                from: $(this).val().replace('<?php echo e($basic->symbol); ?> ', "")
            });
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.fontEnd', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>