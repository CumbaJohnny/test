<?php $__env->startSection('style'); ?>
    <link href="<?php echo e(asset('assets/admin/css/bootstrap-toggle.min.css')); ?>" rel="stylesheet">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>



    <div class="portlet box blue-hoki">
        <div class="portlet-title">
            <div class="caption">
                <i class="fa fa-money"></i>Payment Method</div>
            <div class="tools">
                <a href="javascript:;" class="collapse"> </a>
                <a href="javascript:;" class="reload"> </a>
                <a href="javascript:;" class="remove"> </a>
            </div>
        </div>

        <div class="portlet-body" style="overflow: hidden">
            <?php echo Form::open(['method'=>'post','files'=>true]); ?>

            <div class="col-md-3 col-sm-12">
                <div class="portlet box blue-hoki">
                    <div class="portlet-title">
                        <div class="caption">
                            <i class="fa fa-paypal"></i>Paypal</div>
                        <div class="tools">
                            <a href="javascript:;" class="collapse"> </a>
                            <a href="javascript:;" class="remove"> </a>
                        </div>
                    </div>
                    <div class="portlet-body">


                        <div class="panel panel-info">
                            <div class="panel-heading">
                                <h1 class="panel-title" style="text-transform: uppercase; font-weight: bold;"><i class="fa fa-cc-paypal"></i> PayPal Details</h1>
                            </div>
                            <div class="panel-body">

                                <div class="form-group">
                                    <label class="col-md-12"><strong style="text-transform: uppercase;">Display Image</strong></label>
                                    <div class="col-md-9">
                                        <input name="paypal_image" class="form-control" type="file">
                                        <br>
                                        <b style="color: red;">Square Size(400X400) JPG image Recommended</b>
                                        <br>
                                        <br>
                                    </div>
                                    <div class="col-md-3">
                                        <img src="<?php echo e(asset('assets/images')); ?>/<?php echo e($paypal->image); ?>" alt="Display Image" style="width: 100%;">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-12"><strong style="text-transform: uppercase;">Display Name</strong></label>
                                    <div class="col-md-12">
                                        <input class="form-control" name="paypal_name" value="<?php echo e($paypal->name); ?>" type="text" required>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-12"><strong style="text-transform: uppercase;">Conversion Rate</strong></label>
                                    <div class="col-md-12">
                                        <div class="input-group mb15">
                                            <span class="input-group-addon"><strong>1 USD = </strong></span>
                                            <input class="form-control" name="paypal_rate" value="<?php echo e($paypal->rate); ?>" type="text" required>
                                            <span class="input-group-addon"><strong><?php echo e($basic->currency); ?></strong></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="panel panel-success">
                            <div class="panel-heading">
                                <h1 class="panel-title" style="text-transform: uppercase; font-weight: bold;">Charge Per Transaction</h1>
                            </div>
                            <div class="panel-body">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label class="col-md-12"><strong style="text-transform: uppercase;">FIXED</strong></label>
                                            <div class="col-md-12">
                                                <div class="input-group mb15">
                                                    <input class="form-control" name="paypal_fix" value="<?php echo e($paypal->fix); ?>" required type="text">
                                                    <span class="input-group-addon"><strong><?php echo e($basic->currency); ?></strong></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label class="col-md-12"><strong style="text-transform: uppercase;">PERCENT</strong></label>
                                            <div class="col-md-12">
                                                <div class="input-group mb15">
                                                    <input class="form-control" name="paypal_percent" value="<?php echo e($paypal->percent); ?>" required type="text">
                                                    <span class="input-group-addon"><i class="fa fa-percent"></i></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div><!-- row 2nd   -->
                            </div>
                        </div>

                        <div class="panel panel-info">
                            <div class="panel-heading">
                                <h1 class="panel-title" style="text-transform: uppercase; font-weight: bold;">Payment Description</h1>
                            </div>
                            <div class="panel-body">
                                <div class="form-group" style="margin-top: 40px;margin-bottom: 135px;">
                                    <label class="col-md-12"><strong style="text-transform: uppercase;">PayPal Business Email</strong></label>
                                    <div class="col-md-12">
                                        <div class="input-group mb15">
                                            <input class="form-control" name="paypal_email" value="<?php echo e($paypal->val1); ?>" required type="text">
                                            <span class="input-group-addon"><b>@</b></span>
                                        </div>

                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-12"><strong style="text-transform: uppercase;">STATUS</strong></label>
                                    <div class="col-md-12">
                                        <input data-toggle="toggle" <?php echo e($paypal->status == 1 ? 'checked' : ''); ?> data-onstyle="success" data-offstyle="danger" data-width="100%" type="checkbox" name="paypal_status">
                                    </div>
                                </div>
                                <br>
                                <br>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-12">
                <div class="portlet box blue-hoki">
                    <div class="portlet-title">
                        <div class="caption">
                            <i class="fa fa-money"></i>Perfect Money </div>
                        <div class="tools">
                            <a href="javascript:;" class="collapse"> </a>
                            <a href="javascript:;" class="remove"> </a>
                        </div>
                    </div>
                    <div class="portlet-body">
                        <div class="panel panel-info">
                            <div class="panel-heading">
                                <h1 class="panel-title" style="text-transform: uppercase; font-weight: bold;"><strong><i class="fa fa-credit-card-alt"></i> Perfect Money</strong></h1>
                            </div>
                            <div class="panel-body">

                                <div class="form-group">
                                    <label class="col-md-12"><strong style="text-transform: uppercase;">Display Image</strong></label>
                                    <div class="col-md-9">
                                        <input name="perfect_image" class="form-control" type="file">
                                        <br>
                                        <b style="color: red;">Square Size(400X400) JPG image Recommended</b>
                                        <br>
                                        <br>
                                    </div>
                                    <div class="col-md-3">
                                        <img src="<?php echo e(asset('assets/images')); ?>/<?php echo e($perfect->image); ?>" alt="Display Image" style="width: 100%;">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-12"><strong style="text-transform: uppercase;">Display Name</strong></label>
                                    <div class="col-md-12">
                                        <input class="form-control" name="perfect_name" value="<?php echo e($perfect->name); ?>" required type="text">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-12"><strong style="text-transform: uppercase;">Conversion Rate</strong></label>
                                    <div class="col-md-12">
                                        <div class="input-group mb15">
                                            <span class="input-group-addon"><strong>1 USD = </strong></span>
                                            <input class="form-control" name="perfect_rate" value="<?php echo e($perfect->rate); ?>" type="text" required>
                                            <span class="input-group-addon"><strong><?php echo e($basic->currency); ?></strong></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="panel panel-success">
                            <div class="panel-heading">
                                <h1 class="panel-title" style="text-transform: uppercase; font-weight: bold;">Charge Per Transaction</h1>
                            </div>
                            <div class="panel-body">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label class="col-md-12"><strong style="text-transform: uppercase;">FIXED</strong></label>
                                            <div class="col-md-12">
                                                <div class="input-group mb15">
                                                    <input class="form-control" name="perfect_fix" value="<?php echo e($perfect->fix); ?>" required type="text">
                                                    <span class="input-group-addon"><strong><?php echo e($basic->currency); ?></strong></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label class="col-md-12"><strong style="text-transform: uppercase;">PERCENT</strong></label>
                                            <div class="col-md-12">
                                                <div class="input-group mb15">
                                                    <input class="form-control" name="perfect_percent" value="<?php echo e($perfect->percent); ?>" required type="text">
                                                    <span class="input-group-addon"><i class="fa fa-percent"></i></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div><!-- row 2nd   -->
                            </div>
                        </div>
                        <div class="panel panel-info">
                            <div class="panel-heading">
                                <h1 class="panel-title" style="text-transform: uppercase; font-weight: bold;">Payment Description</h1>
                            </div>
                            <div class="panel-body">
                                <div class="form-group">
                                    <label class="col-md-12"><strong style="text-transform: uppercase;">Perfect Money USD Account</strong></label>
                                    <div class="col-md-12" style="margin-bottom: 21px;">
                                        <div class="input-group mb15">
                                            <input class="form-control" name="perfect_account" value="<?php echo e($perfect->val1); ?>" type="text">
                                            <span class="input-group-addon"><i class="fa fa-send"></i></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-12"><strong style="text-transform: uppercase;">Perfect Money Alternate Passphrase  </strong></label>
                                    <div class="col-md-12">
                                        <div class="input-group mb15">
                                            <input class="form-control" name="perfect_alternate" value="<?php echo e($perfect->val2); ?>" type="text">
                                            <span class="input-group-addon"><i class="fa fa-bolt"></i></span>
                                        </div>
                                    </div>
                                </div>
                                <br>
                                <div class="form-group">
                                    <label class="col-md-12"><strong style="text-transform: uppercase;">STATUS</strong></label>
                                    <div class="col-md-12">
                                        <input data-toggle="toggle" <?php echo e($perfect->status == 1 ? 'checked' : ''); ?> data-onstyle="success" data-offstyle="danger" data-width="100%" type="checkbox" name="perfect_status">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-12">
                <div class="portlet box blue-hoki">
                    <div class="portlet-title">
                        <div class="caption">
                            <i class="fa fa-btc"></i>BTC ( BlockChain )</div>
                        <div class="tools">
                            <a href="javascript:;" class="collapse"> </a>
                            <a href="javascript:;" class="remove"> </a>
                        </div>
                    </div>
                    <div class="portlet-body">
                        <div class="panel panel-info">
                            <div class="panel-heading">
                                <h1 class="panel-title" style="text-transform: uppercase; font-weight: bold;"><strong><i class="fa fa-btc"></i> BlockChain - (BITCOIN)</strong></h1>
                            </div>
                            <div class="panel-body">

                                <div class="form-group">
                                    <label class="col-md-12"><strong style="text-transform: uppercase;">Display Image</strong></label>
                                    <div class="col-md-9">
                                        <input name="btc_image" class="form-control" type="file">
                                        <br>
                                        <b style="color: red;">Square Size(400X400) JPG image Recommended</b>
                                        <br>
                                        <br>
                                    </div>
                                    <div class="col-md-3">
                                        <img src="<?php echo e(asset('assets/images')); ?>/<?php echo e($btc->image); ?>" alt="Display Image" style="width: 100%;">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-12"><strong style="text-transform: uppercase;">Display Name</strong></label>
                                    <div class="col-md-12">
                                        <input class="form-control" name="btc_name" value="<?php echo e($btc->name); ?>" type="text">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-12"><strong style="text-transform: uppercase;">Conversion Rate</strong></label>
                                    <div class="col-md-12">
                                        <div class="input-group mb15">
                                            <span class="input-group-addon"><strong>1 USD = </strong></span>
                                            <input class="form-control" name="btc_rate" value="<?php echo e($btc->rate); ?>" type="text" required>
                                            <span class="input-group-addon"><strong><?php echo e($basic->currency); ?></strong></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="panel panel-success">
                            <div class="panel-heading">
                                <h1 class="panel-title" style="text-transform: uppercase; font-weight: bold;">Charge Per Transaction</h1>
                            </div>
                            <div class="panel-body">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label class="col-md-12"><strong style="text-transform: uppercase;">FIXED</strong></label>
                                            <div class="col-md-12">
                                                <div class="input-group mb15">
                                                    <input class="form-control" name="btc_fix" value="<?php echo e($btc->fix); ?>" required type="text">
                                                    <span class="input-group-addon"><strong><?php echo e($basic->currency); ?></strong></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label class="col-md-12"><strong style="text-transform: uppercase;">PERCENT</strong></label>
                                            <div class="col-md-12">
                                                <div class="input-group mb15">
                                                    <input class="form-control" name="btc_percent" value="<?php echo e($btc->percent); ?>" required type="text">
                                                    <span class="input-group-addon"><i class="fa fa-percent"></i></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div><!-- row 2nd   -->
                            </div>
                        </div>
                        <div class="panel panel-info">
                            <div class="panel-heading">
                                <h1 class="panel-title" style="text-transform: uppercase; font-weight: bold;">Payment Description</h1>
                            </div>
                            <div class="panel-body">
                                <div class="form-group">
                                    <label class="col-md-12"><strong style="text-transform: uppercase;">BitCoin API Key</strong></label>
                                    <div class="col-md-12">
                                        <div class="input-group mb15">
                                            <input class="form-control" name="btc_api" value="<?php echo e($btc->val1); ?>" type="text">
                                            <span class="input-group-addon"><i class="fa fa-key"></i></span>
                                        </div>
                                    </div>
                                </div>
                                <br>
                                <br>
                                <br>
                                <div class="form-group">
                                    <label class="col-md-12"><strong style="text-transform: uppercase;">BitCoin XPUB Code  </strong></label>
                                    <div class="col-md-12">
                                        <div class="input-group mb15">
                                            <input class="form-control" name="btc_xpub" value="<?php echo e($btc->val2); ?>" type="text">
                                            <span class="input-group-addon"><i class="fa fa-code"></i></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-12"><strong style="text-transform: uppercase;">STATUS</strong></label>
                                    <div class="col-md-12">
                                        <input data-toggle="toggle" <?php echo e($btc->status == 1 ? 'checked' : ''); ?> data-onstyle="success" data-offstyle="danger" data-width="100%" type="checkbox" name="btc_status">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-12">
                <div class="portlet box blue-hoki">
                    <div class="portlet-title">
                        <div class="caption">
                            <i class="fa fa-credit-card"></i>Credit Card </div>
                        <div class="tools">
                            <a href="javascript:;" class="collapse"> </a>
                            <a href="javascript:;" class="remove"> </a>
                        </div>
                    </div>
                    <div class="portlet-body">
                        <div class="panel panel-info">
                            <div class="panel-heading">
                                <h1 class="panel-title" style="text-transform: uppercase; font-weight: bold;"><strong><i class="fa fa-cc-stripe"></i> Stripe (CARD)</strong></h1>
                            </div>
                            <div class="panel-body">

                                <div class="form-group">
                                    <label class="col-md-12"><strong style="text-transform: uppercase;">Display Image</strong></label>
                                    <div class="col-md-9">
                                        <input name="stripe_image" class="form-control" type="file">
                                        <br>
                                        <b style="color: red;">Square Size(400X400) JPG image Recommended</b>
                                        <br>
                                        <br>
                                    </div>
                                    <div class="col-md-3">
                                        <img src="<?php echo e(asset('assets/images')); ?>/<?php echo e($stripe->image); ?>" alt="Display Image" style="width: 100%;">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-12"><strong style="text-transform: uppercase;">Display Name</strong></label>
                                    <div class="col-md-12">
                                        <input class="form-control" name="stripe_name" value="<?php echo e($stripe->name); ?>" type="text">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-12"><strong style="text-transform: uppercase;">Conversion Rate</strong></label>
                                    <div class="col-md-12">
                                        <div class="input-group mb15">
                                            <span class="input-group-addon"><strong>1 USD = </strong></span>
                                            <input class="form-control" name="stripe_rate" value="<?php echo e($stripe->rate); ?>" type="text" required>
                                            <span class="input-group-addon"><strong><?php echo e($basic->currency); ?></strong></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="panel panel-success">
                            <div class="panel-heading">
                                <h1 class="panel-title" style="text-transform: uppercase; font-weight: bold;">Charge Per Transaction</h1>
                            </div>
                            <div class="panel-body">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label class="col-md-12"><strong style="text-transform: uppercase;">FIXED</strong></label>
                                            <div class="col-md-12">
                                                <div class="input-group mb15">
                                                    <input class="form-control" name="stripe_fix" value="<?php echo e($stripe->fix); ?>" required type="text">
                                                    <span class="input-group-addon"><strong><?php echo e($basic->currency); ?></strong></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label class="col-md-12"><strong style="text-transform: uppercase;">PERCENT</strong></label>
                                            <div class="col-md-12">
                                                <div class="input-group mb15">
                                                    <input class="form-control" name="stripe_percent" value="<?php echo e($stripe->percent); ?>" required type="text">
                                                    <span class="input-group-addon"><i class="fa fa-percent"></i></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div><!-- row 2nd   -->
                            </div>
                        </div>
                        <div class="panel panel-info">
                            <div class="panel-heading">
                                <h1 class="panel-title" style="text-transform: uppercase; font-weight: bold;">Payment Description</h1>
                            </div>
                            <div class="panel-body">
                                <div class="form-group">
                                    <label class="col-md-12"><strong style="text-transform: uppercase;">SECRET KEY</strong></label>
                                    <div class="col-md-12">
                                        <div class="input-group mb15">
                                            <input class="form-control" name="stripe_secret" value="<?php echo e($stripe->val1); ?>" type="text">
                                            <span class="input-group-addon"><i class="fa fa-key"></i></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-12"><strong style="text-transform: uppercase;">PUBLISHER KEY</strong></label>
                                    <div class="col-md-12">
                                        <div class="input-group mb15">
                                            <input class="form-control" name="stripe_publishable" value="<?php echo e($stripe->val2); ?>" type="text">
                                            <span class="input-group-addon"><i class="fa fa-key"></i></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-md-12"><strong style="text-transform: uppercase;">STATUS</strong></label>
                                    <div class="col-md-12">
                                        <input data-toggle="toggle" <?php echo e($stripe->status == 1 ? 'checked' : ''); ?> data-onstyle="success" data-offstyle="danger" data-width="100%" type="checkbox" name="stripe_status">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <hr>
            <div class="row">
                <div class="col-md-12">
                    <button class="btn btn-info btn-block"><i class="fa fa-send"></i> <strong>Save Changes</strong></button>
                </div>
            </div>

            <?php echo Form::close(); ?>

        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('assets/admin/js/bootstrap-toggle.min.js')); ?>"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>