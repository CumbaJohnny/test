<?php $__env->startSection('content'); ?>



    <div class="row">
        <div class="col-md-12">
            <h3 class="page_title"><?php echo $page_title; ?> </h3>
            <hr>
        </div>
    </div>

    <div class="row">
        <?php if($paypal->status == 1): ?>
            <div class="col-md-3">
                <div class="panel panel-primary" data-collapsed="0">
                    <!-- panel head -->
                    <div class="panel-heading">
                        <div class="panel-title"><i class="fa fa-paypal"></i> <strong><?php echo e($paypal->name); ?></strong></div>

                    </div>
                    <!-- panel body -->
                    <div class="panel-body">
                        <img width="100%" class="image-responsive" src="<?php echo e(asset('assets/images')); ?>/<?php echo e($paypal->image); ?>" alt="">
                    </div>
                    <div class="panel-footer">
                        <a href="javascript:;" onclick="jQuery('#modal-1').modal('show');" class="btn btn-primary btn-block btn-icon icon-lef bold uppercaset"><i class="fa fa-money"></i> ADD FUND</a>
                    </div>
                </div>
            </div>
        <?php endif; ?>
        <?php if($perfect->status == 1): ?>
            <div class="col-md-3">
                <div class="panel panel-primary" data-collapsed="0">
                    <!-- panel head -->
                    <div class="panel-heading">
                        <div class="panel-title"><i class="fa fa-money"></i> <strong><?php echo e($perfect->name); ?></strong></div>

                    </div>
                    <!-- panel body -->
                    <div class="panel-body">
                        <img width="100%" class="image-responsive" src="<?php echo e(asset('assets/images')); ?>/<?php echo e($perfect->image); ?>" alt="">
                    </div>
                    <div class="panel-footer">
                        <a href="javascript:;" onclick="jQuery('#modal-2').modal('show');" class="btn btn-primary btn-block btn-icon icon-left bold uppercase"><i class="fa fa-money"></i> ADD FUND</a>
                    </div>
                </div>
            </div>
        <?php endif; ?>
        <?php if($btc->status == 1): ?>
            <div class="col-md-3">
                <div class="panel panel-primary" data-collapsed="0">
                    <!-- panel head -->
                    <div class="panel-heading">
                        <div class="panel-title"><i class="fa fa-btc"></i> <strong><?php echo e($btc->name); ?></strong></div>

                    </div>
                    <!-- panel body -->
                    <div class="panel-body">
                        <img width="100%" class="image-responsive" src="<?php echo e(asset('assets/images')); ?>/<?php echo e($btc->image); ?>" alt="">
                    </div>
                    <div class="panel-footer">
                        <a href="javascript:;" onclick="jQuery('#modal-3').modal('show');" class="btn btn-primary btn-block btn-icon icon-left"><i class="fa fa-money"></i> ADD FUND</a>
                    </div>
                </div>
            </div>
        <?php endif; ?>
        <?php if($stripe->status == 1): ?>
            <div class="col-md-3">
                <div class="panel panel-primary" data-collapsed="0">
                    <!-- panel head -->
                    <div class="panel-heading">
                        <div class="panel-title"><i class="fa fa-credit-card"></i> <strong><?php echo e($stripe->name); ?></strong></div>

                    </div>
                    <!-- panel body -->
                    <div class="panel-body">
                        <img width="100%" class="image-responsive" src="<?php echo e(asset('assets/images')); ?>/<?php echo e($stripe->image); ?>" alt="">
                    </div>
                    <div class="panel-footer">
                        <a href="javascript:;" onclick="jQuery('#modal-4').modal('show');" class="btn btn-primary btn-block btn-icon icon-left"><i class="fa fa-money"></i> ADD FUND</a>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
    <hr>
    <div class="row">
        <?php $__currentLoopData = $bank; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-3">
                <div class="panel panel-primary" data-collapsed="0">
                    <!-- panel head -->
                    <div class="panel-heading">
                        <div class="panel-title"><i class="fa fa-bank"></i> <strong><?php echo e($b->name); ?></strong></div>
                    </div>
                    <!-- panel body -->
                    <div class="panel-body">
                        <img width="100%" class="image-responsive" src="<?php echo e(asset('assets/images')); ?>/<?php echo e($b->image); ?>" alt="">
                    </div>
                    <div class="panel-footer">
                        <a href="javascript:;" onclick="jQuery('#modal-<?php echo e($b->id); ?>').modal('show');" class="btn btn-primary btn-block btn-icon icon-left"><i class="fa fa-money"></i> ADD FUND</a>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="modal fade" id="modal-1">
        <div class="modal-dialog">
            <div class="modal-content">

                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title bold uppercase"><i class="fa fa-cloud-download"></i> Add Fund via Paypal</h4>
                </div>
                <?php echo e(Form::open()); ?>

                <input type="hidden" name="payment_type" value="1">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-12">

                            <label style="font-size: 14px;margin-top: 30px;" class="col-sm-2 col-sm-offset-1 control-label"><strong>Amount : </strong></label>
                            <div class="col-sm-9">
                                <span style="margin-bottom: 10px;"><code>Deposit Charge : (<?php echo e($paypal->fix); ?> + <?php echo e($paypal->percent); ?> %) - <?php echo e($basic->currency); ?></code></span>
                                <div class="input-group" style="margin-top: 10px;margin-bottom: 10px;">
                                        <input type="number" value="" id="amount" name="amount" class="form-control" required />
                                        <span class="input-group-addon">&nbsp;<strong><?php echo e($basic->currency); ?></strong></span>
                                    </div>
                                </div>
                            </div>
                            <br>
                            <br>
                            <div class="form-group">
                                <div class="col-sm-9 col-sm-offset-3">
                                    <button class="btn btn-primary btn-block bold uppercase"><i class="fa fa-send"></i> Add Fund</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php echo e(Form::close()); ?>

            </div>
        </div>
    </div>
    <div class="modal fade" id="modal-2">
        <div class="modal-dialog">
            <div class="modal-content">

                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title bold uppercase"><i class="fa fa-cloud-download"></i> Add Fund via Perfect Money</h4>
                </div>
                <?php echo e(Form::open()); ?>

                <input type="hidden" name="payment_type" value="2">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-12">

                            <label style="font-size: 14px;margin-top: 30px;" class="col-sm-2 col-sm-offset-1 control-label"><strong>Amount : </strong></label>
                            <div class="col-sm-9">
                                <span style="margin-bottom: 10px;"><code>Deposit Charge : (<?php echo e($perfect->fix); ?> + <?php echo e($perfect->percent); ?> %) - <?php echo e($basic->currency); ?></code></span>
                                <div class="input-group" style="margin-top: 10px;margin-bottom: 10px;">
                                        <input type="number" value="" id="amount" name="amount" class="form-control" required />
                                        <span class="input-group-addon">&nbsp;<strong><?php echo e($basic->currency); ?></strong></span>
                                    </div>
                                </div>
                            </div>
                            <br>
                            <br>
                            <div class="form-group">
                                <div class="col-sm-9 col-sm-offset-3">
                                    <button class="btn btn-primary btn-block bold uppercase"><i class="fa fa-send"></i> Add Fund</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php echo e(Form::close()); ?>

            </div>
        </div>
    </div>
    <div class="modal fade" id="modal-3">
        <div class="modal-dialog">
            <div class="modal-content">

                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title bold uppercase"><i class="fa fa-cloud-download"></i> Add Fund via BTC - BlockChain</h4>
                </div>
                <?php echo e(Form::open()); ?>

                <input type="hidden" name="payment_type" value="3">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label style="font-size: 14px;margin-top: 30px;" class="col-sm-2 col-sm-offset-1 control-label"><strong>Amount : </strong></label>
                                <div class="col-sm-9">
                                    <span style="margin-bottom: 10px;"><code>Deposit Charge : (<?php echo e($btc->fix); ?> + <?php echo e($btc->percent); ?> %) - <?php echo e($basic->currency); ?></code></span>
                                    <div class="input-group" style="margin-top: 10px;margin-bottom: 10px;">
                                        <input type="number" value="" id="amount" name="amount" class="form-control" required />
                                        <span class="input-group-addon">&nbsp;<strong><?php echo e($basic->currency); ?></strong></span>
                                    </div>
                                </div>
                            </div>
                            <br>
                            <br>
                            <div class="form-group">
                                <div class="col-sm-9 col-sm-offset-3">
                                    <button class="btn btn-primary btn-block bold uppercase"><i class="fa fa-send"></i> Add Fund</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php echo e(Form::close()); ?>

            </div>
        </div>
    </div>
    <div class="modal fade" id="modal-4">
        <div class="modal-dialog">
            <div class="modal-content">

                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title bold uppercase"><i class="fa fa-cloud-download"></i> Add Fund via Credit Card</h4>
                </div>
                <?php echo e(Form::open()); ?>

                <input type="hidden" name="payment_type" value="4">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label style="font-size: 14px;margin-top: 30px;" class="col-sm-2 col-sm-offset-1 control-label"><strong>Amount : </strong></label>
                                <div class="col-sm-9">
                                    <span style="margin-bottom: 10px;"><code>Deposit Charge : (<?php echo e($stripe->fix); ?> + <?php echo e($stripe->percent); ?> %) - <?php echo e($basic->currency); ?></code></span>
                                    <div class="input-group" style="margin-top: 10px;margin-bottom: 10px;">
                                        <input type="number" value="" id="amount" name="amount" class="form-control" required />
                                        <span class="input-group-addon">&nbsp;<strong><?php echo e($basic->currency); ?></strong></span>
                                    </div>
                                </div>
                            </div>
                            <br>
                            <br>
                            <div class="form-group">
                                <div class="col-sm-9 col-sm-offset-3">
                                    <button class="btn btn-primary btn-block bold uppercase"><i class="fa fa-send"></i> Add Fund</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php echo e(Form::close()); ?>

            </div>
        </div>
    </div>

    <?php $__currentLoopData = $bank; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


        <div class="modal fade" id="modal-<?php echo e($b->id); ?>">
            <div class="modal-dialog">
                <div class="modal-content">

                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        <h4 class="modal-title bold"><i class="fa fa-cloud-download"></i> <strong>Add Fund via <?php echo e($b->name); ?></strong> </h4>
                    </div>
                    <?php echo e(Form::open()); ?>

                    <input type="hidden" name="payment_type" value="<?php echo e($b->id); ?>">
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label style="font-size: 14px;margin-top: 30px;" class="col-sm-2 col-sm-offset-1 control-label"><strong>Amount : </strong></label>
                                    <div class="col-sm-9">
                                        <span style="margin-bottom: 10px;"><code>Deposit Charge : (<?php echo e($b->fix); ?> + <?php echo e($b->percent); ?>%) - <?php echo e($basic->currency); ?></code></span>
                                        <div class="input-group" style="margin-top: 10px;margin-bottom: 10px;">
                                            <input type="number" value="" id="amount" name="amount" class="form-control" required />
                                            <span class="input-group-addon">&nbsp;<strong><?php echo e($basic->currency); ?></strong></span>
                                        </div>
                                    </div>
                                </div>
                                <br>
                                <br>
                                <div class="form-group">
                                    <div class="col-sm-9 col-sm-offset-3">
                                        <button class="btn btn-primary btn-block bold uppercase"><i class="fa fa-send"></i> Add Fund</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php echo e(Form::close()); ?>

                </div>
            </div>
        </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
    <?php if(session('message')): ?>

        <script type="text/javascript">

            $(document).ready(function(){

                swal("Success!", "<?php echo e(session('message')); ?>", "success");

            });

        </script>

    <?php endif; ?>



    <?php if(session('alert')): ?>

        <script type="text/javascript">

            $(document).ready(function(){

                swal("Sorry!", "<?php echo e(session('alert')); ?>", "error");

            });

        </script>

    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user-frontend.user-dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>